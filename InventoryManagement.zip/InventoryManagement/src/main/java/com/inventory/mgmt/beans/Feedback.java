package com.inventory.mgmt.beans;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Feedback {
	
	private int feedbackId;
	private String feedbackName;
	private String feedbackDescription;		
	private String createdBy;	
	private Date createdDate;
	private int taskId;
	
	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", feedbackName=" + feedbackName + ", feedbackDescription="
				+ feedbackDescription + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", taskId="
				+ taskId + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((feedbackDescription == null) ? 0 : feedbackDescription.hashCode());
		result = prime * result + feedbackId;
		result = prime * result + ((feedbackName == null) ? 0 : feedbackName.hashCode());
		result = prime * result + taskId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Feedback other = (Feedback) obj;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (feedbackDescription == null) {
			if (other.feedbackDescription != null)
				return false;
		} else if (!feedbackDescription.equals(other.feedbackDescription))
			return false;
		if (feedbackId != other.feedbackId)
			return false;
		if (feedbackName == null) {
			if (other.feedbackName != null)
				return false;
		} else if (!feedbackName.equals(other.feedbackName))
			return false;
		if (taskId != other.taskId)
			return false;
		return true;
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getFeedbackName() {
		return feedbackName;
	}
	public void setFeedbackName(String feedbackName) {
		this.feedbackName = feedbackName;
	}
	public String getFeedbackDescription() {
		return feedbackDescription;
	}
	public void setFeedbackDescription(String feedbackDescription) {
		this.feedbackDescription = feedbackDescription;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@JsonFormat
	  (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	
	
	

}
