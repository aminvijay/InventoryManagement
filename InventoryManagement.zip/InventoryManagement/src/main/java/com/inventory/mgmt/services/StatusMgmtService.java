package com.inventory.mgmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.mgmt.beans.Status;
import com.inventory.mgmt.dao.StatusRepository;

@Service("statusManagementService")
public class StatusMgmtService {
	
	@Autowired
    private StatusRepository statusRepository;
	
	public Status findByStatusId(long statusId) {
		return statusRepository.findByStatusId(statusId);
	}
	
	public List<Status> findAllStatus() {		
		return statusRepository.findAllStatus();
	}

}
