package com.inventory.mgmt.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.inventory.mgmt.beans.Feedback;
import com.inventory.mgmt.beans.Note;
import com.inventory.mgmt.beans.Priority;
import com.inventory.mgmt.beans.Status;
import com.inventory.mgmt.beans.Task;
import com.inventory.mgmt.beans.TaskProgress;
import com.inventory.mgmt.services.FeedbackMgmtService;
import com.inventory.mgmt.services.NoteMgmtService;
import com.inventory.mgmt.services.PriorityMgmtService;
import com.inventory.mgmt.services.StatusMgmtService;
import com.inventory.mgmt.services.TaskMgmtService;
import com.inventory.mgmt.services.TaskProgressMgmtService;


@RestController
@RequestMapping("/InventoryManagement")
public class InventoryMgmtController {
	
	private static final Logger logger = LoggerFactory.getLogger(InventoryMgmtController.class);
	
	
	@Autowired
	@Qualifier("statusManagementService")
    private StatusMgmtService statusMgmtService;
	
	@Autowired
	@Qualifier("noteManagementService")
    private NoteMgmtService noteMgmtService;
	
	@Autowired
	@Qualifier("feedbackManagementService")
    private FeedbackMgmtService feedbackMgmtService;
	
	@Autowired
	@Qualifier("priorityManagementService")
    private PriorityMgmtService priorityMgmtService;
	
	@Autowired
	@Qualifier("taskProgressManagementService")
    private TaskProgressMgmtService taskProgressMgmtService;
	
	@Autowired
	@Qualifier("taskManagementService")
    private TaskMgmtService taskMgmtService;
	
	
	@RequestMapping(path="/statuses", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public List<Status> getStatus() {
		return statusMgmtService.findAllStatus();
	}
	
	@RequestMapping(path="/statuses/{id}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<Status> getStatusByID(@PathVariable("id") long id) {
		Status status =  statusMgmtService.findByStatusId(id);
		
		return new ResponseEntity<Status>(status, HttpStatus.OK);
	}
	
	@RequestMapping(path="/notes/{noteId}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<Note> getNoteById(@PathVariable("noteId") long noteId) {
		Note note =  noteMgmtService.findByNoteId(noteId);
		
		return new ResponseEntity<Note>(note, HttpStatus.OK);
	}
	
	@RequestMapping(path="/tasks/{taskId}/notes", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<List<Note>> findNoteByTaskId(@PathVariable("taskId") long taskId) {
		List<Note> notes =  noteMgmtService.findNoteByTaskId(taskId);
		
		return new ResponseEntity<List<Note>>(notes, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/tasks/{taskId}/notes", method = RequestMethod.POST)
	public ResponseEntity<Void> insertNote(@PathVariable("taskId") int taskId, @RequestBody Note note, 	UriComponentsBuilder ucBuilder) {
		
		note.setTaskId(taskId);
		int lastId = noteMgmtService.insertNote(note);
		
		System.out.println("last Note Id = " + lastId) ;

		/*HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/tasks/{taskId}/notes/{id}").buildAndExpand(lastId).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);*/
		return new ResponseEntity<Void>(HttpStatus.CREATED);
		
	}
	
	
	
	@RequestMapping(path="/feedbacks/{feedbackId}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<Feedback> findByFeedbackId(@PathVariable("feedbackId") long feedbackId) {
		Feedback feedback =  feedbackMgmtService.findByFeedbackId(feedbackId);
		
		return new ResponseEntity<Feedback>(feedback, HttpStatus.OK);
	}
	
	@RequestMapping(path="/tasks/{taskId}/feedbacks", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<List<Feedback>> findFeedbackByTaskId(@PathVariable("taskId") long taskId) {
		List<Feedback> feedbacks =  feedbackMgmtService.findFeedbackByTaskId(taskId);
		
		return new ResponseEntity<List<Feedback>>(feedbacks, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/tasks/{taskId}/feedbacks", method = RequestMethod.POST)
	public ResponseEntity<Void> insertFeedback(@PathVariable("taskId") int taskId, @RequestBody Feedback feedback, 	UriComponentsBuilder ucBuilder) {
		
		feedback.setTaskId(taskId);
		feedbackMgmtService.insertFeedback(feedback);

		/*HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/tasks/{taskId}/feedbacks/{id}").buildAndExpand(feedback.getFeedbackId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);*/
		return new ResponseEntity<Void>(HttpStatus.CREATED);
		
	}
	
	@RequestMapping(path="/priorities", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public List<Priority> findAllPriority() {
		return priorityMgmtService.findAllPriority();
	}
	
	@RequestMapping(path="/priorities/{id}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<Priority> findByPriorityId(@PathVariable("id") long id) {
		Priority status =  priorityMgmtService.findByPriorityId(id);
		
		return new ResponseEntity<Priority>(status, HttpStatus.OK);
	}
	

	@RequestMapping(path="/taskProgresses/{taskProgressId}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<TaskProgress> findByTaskProgressId(@PathVariable("taskProgressId") long taskProgressId) {
		
		TaskProgress taskProgress =  taskProgressMgmtService.findByTaskProgressId(taskProgressId);		
		return new ResponseEntity<TaskProgress>(taskProgress, HttpStatus.OK);
	}
	
	@RequestMapping(path="/tasks/{taskId}/taskProgresses", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<List<TaskProgress>> findTaskProgressByTaskId(@PathVariable("taskId") long taskId) {
		
		List<TaskProgress> taskProgresses =  taskProgressMgmtService.findTaskProgressByTaskId(taskId);		
		return new ResponseEntity<List<TaskProgress>>(taskProgresses, HttpStatus.OK);
	}
	
	/* No Need to expose
	@RequestMapping(value = "/tasks/{taskId}/taskProgresses", method = RequestMethod.POST)
	public ResponseEntity<Void> insertTaskProgress(@PathVariable("taskId") long taskId, @RequestBody TaskProgress taskProgress, 	UriComponentsBuilder ucBuilder) {
		
		taskProgressMgmtService.insertTaskProgress(taskProgress);		
		return new ResponseEntity<Void>(HttpStatus.CREATED);		
	}
		
	*/
	
	@RequestMapping(path="/tasks/{taskId}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<Task> findByTaskId(@PathVariable("taskId") long taskId) {
		
		Task task =  taskMgmtService.findByTaskId(taskId);		
		return new ResponseEntity<Task>(task, HttpStatus.OK);
	}
	
	@RequestMapping(path="/tasks/statuses/{statusId}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<List<Task>> findTaskByStatusId(@PathVariable("statusId") long statusId) {
		
		List<Task> taskList =  taskMgmtService.findTaskByStatusId(statusId);		
		return new ResponseEntity<List<Task>>(taskList, HttpStatus.OK);
	}
	
	@RequestMapping(path="/tasks/priorities/{priorityId}", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<List<Task>> findTaskByPriorityId(@PathVariable("priorityId") long priorityId) {
		
		List<Task> taskList =  taskMgmtService.findTaskByPriorityId(priorityId);		
		return new ResponseEntity<List<Task>>(taskList, HttpStatus.OK);
	}
	
	@RequestMapping(path="/tasks", method = RequestMethod.GET, headers="Accept=application/json",produces="application/json")
	public ResponseEntity<List<Task>> findAllTask() {
		
		List<Task> taskList =  taskMgmtService.findAllTask();		
		return new ResponseEntity<List<Task>>(taskList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/tasks", method = RequestMethod.POST)
	public ResponseEntity<Void> insertTask( @RequestBody Task task, 	UriComponentsBuilder ucBuilder) {
		
		taskMgmtService.insertTask(task);		
		return new ResponseEntity<Void>(HttpStatus.CREATED);
		
	}
	
	@RequestMapping(value = "/tasks/{taskId}", method = RequestMethod.PUT)
	public ResponseEntity<Task> updateTask(@PathVariable("taskId") int taskId, @RequestBody Task task) {
		
		
		Task originalTask =  taskMgmtService.findByTaskId(taskId);
		
		if (originalTask==null) {
			System.out.println("Task with id " + taskId + " not found");
			return new ResponseEntity<Task>(HttpStatus.NOT_FOUND);
		}
		
		task.setTaskId(taskId);

		taskMgmtService.updateTask(task);
		
		
		return new ResponseEntity<Task>(taskMgmtService.findByTaskId(taskId), HttpStatus.OK);
	}
}
