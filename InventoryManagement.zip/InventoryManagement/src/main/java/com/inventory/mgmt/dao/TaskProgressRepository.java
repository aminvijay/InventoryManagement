package com.inventory.mgmt.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inventory.mgmt.beans.TaskProgress;

@Repository
public class TaskProgressRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public TaskProgress findByTaskProgressId(long id) {
	    	return jdbcTemplate.queryForObject("select * from TaskProgress where taskProgressId=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper <TaskProgress> (TaskProgress.class));
	}
	
	public List<TaskProgress> findTaskProgressByTaskId(long taskId) {	    
		
		String sql = "select * from TaskProgress where taskId=? order by taskProgressId";
		
		List<TaskProgress> noteList =  jdbcTemplate.query(sql, new Object[] {
				taskId
	        },
				new BeanPropertyRowMapper(TaskProgress.class));
		
		return noteList;
	}
	
	public void insertTaskProgress(TaskProgress taskProgress){
		
		String sql = "INSERT INTO TaskProgress " +
				"(taskId, statusId, createdBy) VALUES (?, ?, ?)";	
					
			jdbcTemplate.update(sql, new Object[] { taskProgress.getTaskId(),taskProgress.getStatusId(),taskProgress.getCreatedBy()
			});
				
	}
	
	public int getLastInsertId() {		
		return jdbcTemplate.queryForObject( " SELECT max(taskProgressId) FROM TaskProgress ",Integer.class);		
	}
	

}
