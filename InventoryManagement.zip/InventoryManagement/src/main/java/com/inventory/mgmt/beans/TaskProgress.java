package com.inventory.mgmt.beans;

import java.sql.Date;
import com.fasterxml.jackson.annotation.JsonFormat;

public class TaskProgress {
	
	private int taskProgressId;
	private int taskId;
	private int statusId;	
	private String createdBy;	
	private Date createdDate;
	
	
	public int getTaskProgressId() {
		return taskProgressId;
	}
	public void setTaskProgressId(int taskProgressId) {
		this.taskProgressId = taskProgressId;
	}
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@JsonFormat
	  (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + statusId;
		result = prime * result + taskId;
		result = prime * result + taskProgressId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskProgress other = (TaskProgress) obj;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (statusId != other.statusId)
			return false;
		if (taskId != other.taskId)
			return false;
		if (taskProgressId != other.taskProgressId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TaskProgress [taskProgressId=" + taskProgressId + ", taskId=" + taskId + ", statusId=" + statusId
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}
	
	
	
	
	

}
