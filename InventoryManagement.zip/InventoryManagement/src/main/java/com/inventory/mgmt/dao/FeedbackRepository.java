package com.inventory.mgmt.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inventory.mgmt.beans.Feedback;
import com.inventory.mgmt.beans.Note;

@Repository
public class FeedbackRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Feedback findByFeedbackId(long id) {
	    	return jdbcTemplate.queryForObject("select * from Feedback where feedbackId=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper <Feedback> (Feedback.class));
	}
	
	public List<Feedback> findFeedbackByTaskId(long taskId) {	    
		
		String sql = "select * from Feedback where taskId=? order by feedbackId";
		
		List<Feedback> feedbackList =  jdbcTemplate.query(sql, new Object[] {
				taskId
	        },
				new BeanPropertyRowMapper(Feedback.class));
		
		return feedbackList;
	}
	
	public void insertFeedback(Feedback feedback){
		
		String sql = "INSERT INTO Feedback " +
			"(feedbackName, feedbackDescription, createdBy,taskId) VALUES (?, ?, ?,?)";			 
		
				
		jdbcTemplate.update(sql, new Object[] { feedback.getFeedbackName(),feedback.getFeedbackDescription(),feedback.getCreatedBy(),feedback.getTaskId()  
		});
				
	}
	
	public int getLastInsertId() {		
		return jdbcTemplate.queryForObject( " SELECT max(feedbackId) FROM Feedback ",Integer.class);		
	}
	

}
