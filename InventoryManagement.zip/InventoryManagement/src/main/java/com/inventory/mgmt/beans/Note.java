package com.inventory.mgmt.beans;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Note {
	
	private int noteId;
	private String noteName;
	private String noteDescription;	
	private String createdBy;	
	private Date createdDate;
	private int taskId;
	
	public int getNoteId() {
		return noteId;
	}
	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}
	public String getNoteName() {
		return noteName;
	}
	public void setNoteName(String noteName) {
		this.noteName = noteName;
	}
	public String getNoteDescription() {
		return noteDescription;
	}
	public void setNoteDescription(String noteDescription) {
		this.noteDescription = noteDescription;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@JsonFormat
	  (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((noteDescription == null) ? 0 : noteDescription.hashCode());
		result = prime * result + noteId;
		result = prime * result + ((noteName == null) ? 0 : noteName.hashCode());
		result = prime * result + taskId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Note other = (Note) obj;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (noteDescription == null) {
			if (other.noteDescription != null)
				return false;
		} else if (!noteDescription.equals(other.noteDescription))
			return false;
		if (noteId != other.noteId)
			return false;
		if (noteName == null) {
			if (other.noteName != null)
				return false;
		} else if (!noteName.equals(other.noteName))
			return false;
		if (taskId != other.taskId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Note [noteId=" + noteId + ", noteName=" + noteName + ", noteDescription=" + noteDescription
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", taskId=" + taskId + "]";
	}
	
	

}
