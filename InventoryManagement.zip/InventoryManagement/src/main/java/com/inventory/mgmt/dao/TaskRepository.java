package com.inventory.mgmt.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inventory.mgmt.beans.Priority;
import com.inventory.mgmt.beans.Status;
import com.inventory.mgmt.beans.Task;

@Repository
public class TaskRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	
	
	public Task findByTaskId(long id) {
		
    	return jdbcTemplate.queryForObject("select * from Task t, Priority p, Status s where t.priorityId = p.priorityId and t.statusId = s.statusId and t.taskId=?", new Object[] {
            id
        },
        new BeanPropertyRowMapper <Task> () {
    		
    		@Override
    	    public Task mapRow(ResultSet rs, int rowNum) throws SQLException {
    	        return getTaskFromResultSet(rs);
    	    }
    	});
	}
	
	public List<Task> findTaskByStatusId(long statusId) {	    
		
		//String sql = "select * from Task t, Priority p, Status s where t.priorityId = p.priorityId and t.statusId = s.statusId and t.statusId=? order by t.taskId,t.priorityId";
		
		String sql = "select * from Task t, Priority p, Status s where t.priorityId = p.priorityId and t.statusId = s.statusId and t.statusId=? order by (t.priorityId * t.estimatedMinutes ) desc";
		
		List<Task> taskList =  jdbcTemplate.query(sql, new Object[] {
				statusId
	        },
				new BeanPropertyRowMapper() {
			
			@Override
    	    public List<Task> mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				List<Task> taskList = new ArrayList<Task>();
				Task task = getTaskFromResultSet(rs);
				taskList.add(task);
				
				while (rs.next()) {					
					task = getTaskFromResultSet(rs);
	    	        taskList.add(task);
				}
    	        return taskList;
    	    }
		});
		
		return taskList;
	}
	
	public List<Task> findTaskByPriorityId(long priorityId) {	    
		
		String sql = "select * from Task t, Priority p, Status s where t.priorityId = p.priorityId and t.statusId = s.statusId and t.priorityId=? order by  t.taskId,t.statusId";
		
		List<Task> taskList =  jdbcTemplate.query(sql, new Object[] {
				priorityId
	        },
				new BeanPropertyRowMapper() {
			
			@Override
    	    public List<Task> mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				List<Task> taskList = new ArrayList<Task>();
				Task task = getTaskFromResultSet(rs);
				taskList.add(task);
				
				while (rs.next()) {					
					task = getTaskFromResultSet(rs);
	    	        taskList.add(task);
				}

    	        return taskList;
    	    }
		});
		
		return taskList;
	}
	
	public void insertTask(Task task){
		
		String sql = "INSERT INTO Task " +
			"(taskName, taskDescription, statusId,priorityId,estimatedMinutes,createdBy,assignedTo) VALUES (?, ?, ?,?, ?, ?,?)";			 
		
				
		jdbcTemplate.update(sql, new Object[] { task.getTaskName(), task.getTaskDescription(), task.getStatus().getStatusId(), task.getPriority().getPriorityId(),
				task.getEstimatedMinutes(), task.getCreatedBy(), task.getAssignedTo()			
				
		});
				
	}
	
	public int getLastInsertId() {		
		return jdbcTemplate.queryForObject( " SELECT max(taskId) FROM Task ",Integer.class);		
	}


	public List<Task> findAllTask() {	    
		
		String sql = "select * from Task t, Priority p, Status s where t.priorityId = p.priorityId and t.statusId = s.statusId order by t.taskId ";
		
		List<Task> taskList =  jdbcTemplate.query(sql, new Object[] {
				
	        },
				new BeanPropertyRowMapper() {
			
			@Override
    	    public List<Task> mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				List<Task> taskList = new ArrayList<Task>();
				Task task = getTaskFromResultSet(rs);
				taskList.add(task);
				
				while (rs.next()) {
					task = getTaskFromResultSet(rs); 
	    	        taskList.add(task);
				}

    	        return taskList;
    	    }
		});
		
		return taskList;
	}

	
	public void updateTask(Task task){
		
		String sql = "UPDATE Task set  taskName = ? , taskDescription = ?, statusId = ?, priorityId = ?, "
				+ " estimatedMinutes = ?,  updatedBy = ?, assignedTo = ? where taskId = ? " ;			 
		
				
		jdbcTemplate.update(sql, new Object[] { task.getTaskName(), task.getTaskDescription(), task.getStatus().getStatusId(), task.getPriority().getPriorityId(),
				task.getEstimatedMinutes(), task.getUpdatedBy(), task.getAssignedTo(), task.getTaskId()			
				
		});
				
	}
	
	private Task getTaskFromResultSet(ResultSet rs) throws SQLException{
		
		Task task = new Task();
		
		task.setTaskId(rs.getInt("taskId"));
		task.setTaskName(rs.getString("taskName"));
		task.setTaskDescription(rs.getString("taskDescription"));
		task.setEstimatedMinutes(rs.getInt("estimatedMinutes"));
		task.setCreatedBy(rs.getString("createdBy"));
		task.setUpdatedBy(rs.getString("updatedBy"));
		task.setAssignedTo(rs.getString("assignedTo"));
		
		task.setCreatedDate(rs.getDate("createdDate"));
		task.setUpdatedDate(rs.getDate("updatedDate"));

		Priority priority = new Priority();
		priority.setPriorityId(rs.getInt("priorityId"));
		priority.setPriorityName(rs.getString("priorityName"));
		priority.setPriorityDescription(rs.getString("priorityDescription"));
		
		task.setPriority(priority);
		
		Status status = new Status();
		status.setStatusId(rs.getInt("statusId"));
		status.setStatusName(rs.getString("statusName"));
		status.setStatusDescription(rs.getString("statusDescription"));
		
        task.setStatus(status);
        
		return task;
        
	}

}
