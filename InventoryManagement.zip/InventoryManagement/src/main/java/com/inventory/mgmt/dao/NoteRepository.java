package com.inventory.mgmt.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inventory.mgmt.beans.Note;

@Repository
public class NoteRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Note findByNoteId(long id) {
	    	return jdbcTemplate.queryForObject("select * from Note where noteId=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper <Note> (Note.class));
	}
	
	public List<Note> findNoteByTaskId(long taskId) {	    
		
		String sql = "select * from Note where taskId=? order by noteId";
		
		List<Note> noteList =  jdbcTemplate.query(sql, new Object[] {
				taskId
	        },
				new BeanPropertyRowMapper(Note.class));
		
		return noteList;
	}
	
	public void insertNote(Note note){
		
		String sql = "INSERT INTO Note " +
			"(noteName, noteDescription, createdBy,taskId) VALUES (?, ?, ?,?)";			 
		
				
		jdbcTemplate.update(sql, new Object[] { note.getNoteName(),note.getNoteDescription(),note.getCreatedBy(),note.getTaskId()  
		});
				
	}
	
	public int getLastInsertId() {		
		return jdbcTemplate.queryForObject( " SELECT max(noteId) FROM Note ",Integer.class);		
	}
}
