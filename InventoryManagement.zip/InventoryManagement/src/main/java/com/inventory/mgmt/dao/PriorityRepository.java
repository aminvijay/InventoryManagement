package com.inventory.mgmt.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inventory.mgmt.beans.Priority;


@Repository
public class PriorityRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Priority findByPriorityId(long id) {
	    return jdbcTemplate.queryForObject("select * from Priority where priorityId=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper <Priority> (Priority.class));
	}
	
	public List<Priority> findAllPriority() {
		
		String sql = "SELECT * FROM Priority order by priorityId ";
		
		List<Priority> statusList =  jdbcTemplate.query(sql,
				new BeanPropertyRowMapper(Priority.class));
		
		return statusList;
	}

}
