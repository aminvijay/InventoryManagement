package com.inventory.mgmt.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inventory.mgmt.beans.Status;


@Repository
public class StatusRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Status findByStatusId(long id) {
	    return jdbcTemplate.queryForObject("select * from Status where statusId=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper <Status> (Status.class));
	}
	
	public List<Status> findAllStatus() {
		
		String sql = "SELECT * FROM Status";
		
		List<Status> statusList =  jdbcTemplate.query(sql,
				new BeanPropertyRowMapper(Status.class));
		
		return statusList;
	}

}
