package com.inventory.mgmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.mgmt.beans.Feedback;
import com.inventory.mgmt.dao.FeedbackRepository;

@Service("feedbackManagementService")
public class FeedbackMgmtService {
	
	@Autowired
    private FeedbackRepository feedbackRepository;
	
	public Feedback findByFeedbackId(long feedbackId) {
		return feedbackRepository.findByFeedbackId(feedbackId);
	}
	
	public List<Feedback> findFeedbackByTaskId(long taskId) {		
		return feedbackRepository.findFeedbackByTaskId(taskId);
	}
	
	public void insertFeedback(Feedback feedback) {		
		feedbackRepository.insertFeedback(feedback);
	}

}
