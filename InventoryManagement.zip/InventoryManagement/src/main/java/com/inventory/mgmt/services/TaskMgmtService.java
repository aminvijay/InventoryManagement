package com.inventory.mgmt.services;

import java.sql.Date;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.mgmt.beans.Priority;
import com.inventory.mgmt.beans.Status;
import com.inventory.mgmt.beans.Task;
import com.inventory.mgmt.beans.TaskProgress;
import com.inventory.mgmt.dao.TaskProgressRepository;
import com.inventory.mgmt.dao.TaskRepository;

@Service("taskManagementService")
public class TaskMgmtService {
	
	@Autowired
    private TaskRepository taskRepository;
	
	@Autowired
    private TaskProgressRepository taskProgressRepository;
	
	
	public Task findByTaskId(long taskId) {
		
		return taskRepository.findByTaskId(taskId);
	}
	
	public List<Task> findTaskByStatusId(long statusId) {	
		
		List<Task> taskList = taskRepository.findTaskByStatusId(statusId);
		
		//System.out.println(" taskList before sort" + taskList);
		
		/*Collections.sort(taskList, new Comparator<Task>() {
			
			@Override
			public int compare(Task task1, Task task2) {
				
				/*int rank1 = task1.getPriority().getPriorityId()*task1.getEstimatedMinutes();
				int rank2 = task2.getPriority().getPriorityId()*task2.getEstimatedMinutes();
				return rank1 - rank2; */
				
				//return task1.getPriority().getPriorityId() - task2.getPriority().getPriorityId();
				/*return task1.getTaskName().compareTo(task2.getTaskName());
			}
			
		});*/
		
		//Collections.sort(taskList,(a,b)->a.getTaskName().compareTo(b.getTaskName()));
		
		
		
		//System.out.println(" taskList after sort" + taskList);
		
		return taskList;
	}
	
	public List<Task> findTaskByPriorityId(long priorityId) {		
		return taskRepository.findTaskByPriorityId(priorityId);
	}
	
	public List<Task> findAllTask() {		
		return taskRepository.findAllTask();
	}
	
	public void insertTask(Task task) {
		
		taskRepository.insertTask(task);
		int lastId = taskRepository.getLastInsertId();
		
		TaskProgress taskProgress = new TaskProgress();
		
		taskProgress.setTaskId(lastId);
		taskProgress.setStatusId(task.getStatus().getStatusId());
		taskProgress.setCreatedBy(task.getCreatedBy());
		
		taskProgressRepository.insertTaskProgress(taskProgress);
		
	}
	
	public void updateTask(Task task) {
		
		boolean statusUpdated = false;
		
		
		Task originalTask = taskRepository.findByTaskId(task.getTaskId());
		
		if(task.getTaskName() != null) {
			originalTask.setTaskName(task.getTaskName());
		}
		
		if(task.getTaskDescription() != null) {
			originalTask.setTaskDescription(task.getTaskDescription());
		}
		
		if(task.getStatus().getStatusId() != originalTask.getStatus().getStatusId()) {
			statusUpdated = true;
			
			Status status = new Status();
			status.setStatusId(task.getStatus().getStatusId());
			originalTask.setStatus(status);
		}
		
		if(task.getPriority().getPriorityId() != originalTask.getPriority().getPriorityId()) {
			
			
			Priority priority = new Priority();
			priority.setPriorityId(task.getPriority().getPriorityId());
			originalTask.setPriority(priority);
		}
		
		if(task.getEstimatedMinutes() != originalTask.getEstimatedMinutes()) {
			originalTask.setEstimatedMinutes(task.getEstimatedMinutes());
		}
		
		originalTask.setUpdatedBy(task.getUpdatedBy());
		originalTask.setUpdatedDate(new Date(System.currentTimeMillis()));
		
		if(task.getAssignedTo() != null) {
			originalTask.setAssignedTo(task.getAssignedTo());
		}
		
		taskRepository.updateTask(originalTask);
		
		if(statusUpdated) {
			
			TaskProgress taskProgress = new TaskProgress();
			
			taskProgress.setTaskId(originalTask.getTaskId());
			taskProgress.setStatusId(task.getStatus().getStatusId());
			taskProgress.setCreatedBy(task.getCreatedBy());
			
			taskProgressRepository.insertTaskProgress(taskProgress);
		}
	}

}
