package com.inventory.mgmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.mgmt.beans.TaskProgress;
import com.inventory.mgmt.dao.TaskProgressRepository;

@Service("taskProgressManagementService")
public class TaskProgressMgmtService {
	
	@Autowired
    private TaskProgressRepository taskProgressRepository;
	
	public TaskProgress findByTaskProgressId(long taskProgressId) {
		return taskProgressRepository.findByTaskProgressId(taskProgressId);
	}
	
	public List<TaskProgress> findTaskProgressByTaskId(long taskId) {		
		return taskProgressRepository.findTaskProgressByTaskId(taskId);
	}
	
	public void insertTaskProgress(TaskProgress taskProgress) {		
		taskProgressRepository.insertTaskProgress(taskProgress);
	}

}
