package com.inventory.mgmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.mgmt.beans.Note;
import com.inventory.mgmt.beans.Status;
import com.inventory.mgmt.dao.NoteRepository;

@Service("noteManagementService")
public class NoteMgmtService {
	
	@Autowired
    private NoteRepository noteRepository;
	
	public Note findByNoteId(long noteId) {
		return noteRepository.findByNoteId(noteId);
	}
	
	public List<Note> findNoteByTaskId(long taskId) {		
		return noteRepository.findNoteByTaskId(taskId);
	}
	
	public int insertNote(Note note) {		
		noteRepository.insertNote(note);
		return noteRepository.getLastInsertId();
	}

}
