package com.inventory.mgmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.mgmt.beans.Priority;
import com.inventory.mgmt.dao.PriorityRepository;

@Service("priorityManagementService")
public class PriorityMgmtService {
	
	@Autowired
    private PriorityRepository priorityRepository;
	
	public Priority findByPriorityId(long priorityId) {
		return priorityRepository.findByPriorityId(priorityId);
	}
	
	public List<Priority> findAllPriority() {		
		return priorityRepository.findAllPriority();
	}

}
