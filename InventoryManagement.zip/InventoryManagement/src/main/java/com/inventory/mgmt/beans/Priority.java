package com.inventory.mgmt.beans;

public class Priority {
	
	private int priorityId;
	private String priorityName;
	private String priorityDescription;
	
	public int getPriorityId() {
		return priorityId;
	}
	public void setPriorityId(int priorityId) {
		this.priorityId = priorityId;
	}
	public String getPriorityName() {
		return priorityName;
	}
	public void setPriorityName(String priorityName) {
		this.priorityName = priorityName;
	}
	public String getPriorityDescription() {
		return priorityDescription;
	}
	public void setPriorityDescription(String priorityDescription) {
		this.priorityDescription = priorityDescription;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((priorityDescription == null) ? 0 : priorityDescription.hashCode());
		result = prime * result + priorityId;
		result = prime * result + ((priorityName == null) ? 0 : priorityName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Priority other = (Priority) obj;
		if (priorityDescription == null) {
			if (other.priorityDescription != null)
				return false;
		} else if (!priorityDescription.equals(other.priorityDescription))
			return false;
		if (priorityId != other.priorityId)
			return false;
		if (priorityName == null) {
			if (other.priorityName != null)
				return false;
		} else if (!priorityName.equals(other.priorityName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Priority [priorityId=" + priorityId + ", priorityName=" + priorityName + ", priorityDescription="
				+ priorityDescription + "]";
	}
	
	
	

}
