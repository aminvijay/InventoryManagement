INSERT INTO `Status` (`statusName`, `statusDescription`) VALUES ('Received', 'Received');
INSERT INTO `Status` (`statusName`, `statusDescription`) VALUES ('Active', 'Active');
INSERT INTO `Status` (`statusName`, `statusDescription`) VALUES ('Hold', 'Hold');
INSERT INTO `Status` (`statusName`, `statusDescription`) VALUES ('Inactive', 'Inactive');
INSERT INTO `Status` (`statusName`, `statusDescription`) VALUES ('Discontinue', 'Discontinue');

INSERT INTO `Priority` (`priorityName`, `priorityDescription`) VALUES ('Low', 'Low');
INSERT INTO `Priority` (`priorityName`, `priorityDescription`) VALUES ('Normal', 'Normal');
INSERT INTO `Priority` (`priorityName`, `priorityDescription`) VALUES ('High', 'High');
INSERT INTO `Priority` (`priorityName`, `priorityDescription`) VALUES ('Extreme', 'Extreme');

