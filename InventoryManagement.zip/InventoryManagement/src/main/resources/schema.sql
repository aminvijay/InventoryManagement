--CREATE DATABASE inventoryMgmt;
--DROP TABLE TASK_MASTER;

CREATE TABLE `Status` (
	`statusId` INT(11) NOT NULL AUTO_INCREMENT,
	`statusName` VARCHAR(50) NULL DEFAULT NULL,
	`statusDescription` VARCHAR(200) NULL DEFAULT NULL,	
	PRIMARY KEY (`statusId`)
);

CREATE TABLE `Priority` (
	`priorityId` INT(11) NOT NULL AUTO_INCREMENT,
	`priorityName` VARCHAR(50) NULL DEFAULT NULL,
	`priorityDescription` VARCHAR(200) NULL DEFAULT NULL,	
	PRIMARY KEY (`priorityId`)
);

CREATE TABLE `Note` (
  	`noteId` INT(11) NOT NULL AUTO_INCREMENT,
  	`noteName` VARCHAR(50) NULL DEFAULT NULL,
  	`noteDescription` VARCHAR(200) NULL DEFAULT NULL,  	
  	`createdDate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  	`createdBy` VARCHAR(50) NULL DEFAULT NULL,
  	`taskId` INT(11) NOT NULL,
  	PRIMARY KEY (`noteId`)
);

CREATE TABLE `Feedback` (
  	`feedbackId` INT(11) NOT NULL AUTO_INCREMENT,
  	`feedbackName` VARCHAR(50) NULL DEFAULT NULL,
  	`feedbackDescription` VARCHAR(200) NULL DEFAULT NULL,  	
  	`createdDate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  	`createdBy` VARCHAR(50) NULL DEFAULT NULL,
  	`taskId` INT(11) NOT NULL,
  	PRIMARY KEY (`feedbackId`)
);

CREATE TABLE `TaskProgress` (
  	`taskProgressId` INT(11) NOT NULL AUTO_INCREMENT,
  	`taskId` INT(11) NOT NULL,
  	`statusId` INT(11) NOT NULL,
  	`createdBy` VARCHAR(50) NULL DEFAULT NULL,	
  	`createdDate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  	PRIMARY KEY (`taskProgressId`)
);


CREATE TABLE `Task` (
	`taskId` INT(11) NOT NULL AUTO_INCREMENT,
	`taskName` VARCHAR(50) NULL DEFAULT NULL,
	`taskDescription` VARCHAR(200) NULL DEFAULT NULL,
	`statusId` INT(11) NOT NULL,
	`priorityId` INT(11) NOT NULL,
	`estimatedMinutes` INT(11) NOT NULL,
	`createdBy` VARCHAR(50) NULL DEFAULT NULL,
	`createdDate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
	`updatedBy` VARCHAR(50) NULL DEFAULT NULL,
	`updatedDate` TIMESTAMP NULL DEFAULT NULL,	
	`assignedTo` VARCHAR(50) NULL DEFAULT NULL,
	PRIMARY KEY (`taskId`)
);


